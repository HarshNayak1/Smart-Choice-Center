<html>
<head>
<title>service page </title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href= "https://fonts.googleapis.com/css?family=Poppins&display=swap"  rel="stylesheet">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="style.css">








</head>
<body>

  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

<script src="textyle.js"></script>

<script type="text/javascript">

$(function(){

$('.demo').textyle({

duration : 500,
delay : 200,
easing : 'linear',
callback :function(){

 $(this).css({

 transform: 'translateY(0px) rotateY(360deg)',

 })

}

})
$('p').textyle()

})

</script>


<section class ="header">
        <div class="content-box">

        <div class="menu">
         <img  src="s.jpeg">

        </div>

<div class= "banner-text">


        <h2 class="demo">DIGITAL SERVICE PROVIDER</h2>
        <b><p>we are here to help you with our skills and knowledge<br>lets switch to digital world</p></b>
        <a href="#hh">SCROLL DOWM</a>

</div>
</div>
</section>


<!--commnent--->


<section  id ="hh"class="service">

  <div class="content-box">
   <div class="container">
     <h1>OUR SERVICES</h1>

   <div class="row services">

     <div class="col-md-3 text-center">
       <div class="icon">
    <i class="fa fa-renren"></i>
       </div>
       <h3>Booking Of Travel Ticket<br><span> service</span></h3>
       <p>
      IRCTC Ticket<br>
      AIR Tickets<br>
      BUS Tickets
       </p>
     </div>

     <div class="col-md-3 text-center">


       <div class="icon">
    <i class="fa fa-renren"></i>
       </div>
       <h3>Exam Form<br>Filling<br><span> service</span></h3>
       <p>
      Government Exam Forms<br>
      Non Government Exam Form<br>
      Online Addmissions Form<br>
      Competative Forms
       </p>
     </div>


     <div class="col-md-3 text-center">
       <div class="icon">
    <i class="fa fa-renren"></i>
       </div>
       <h3>Id Proof Linking<br> And Generating<br><span> service</span></h3>
       <p>
      Aadhar Card<br>
       PAN Card<br>
       Ration Card<br>
       Voter Id Card<br>
       etc.

       </p>
     </div>


     <div class="col-md-3 text-center">
       <div class="icon">
    <i class="fa fa-renren"></i>
       </div>
       <h3>Banking<br> Related<br><span> service</span></h3>
       <p>
      Money Withdrawal<br>
      Money Deposite<br>
      Statement Of Accounts<br>
      Balance Enquiry<br>
      And Other Facilities
       </p>
     </div>

   </div>
</div>
 </div>
</section>


<!--jfnfnafffj----->

<section class="feature">
  <div class="content-box">
  <div class="container">

  <h1>SBI BANK</h1>






   <img src="modi.jpg" class="slide-1">
        <img src="sb.png" class="slide-2">
           <img src="sb3.jpeg" class="slide-3">
           <img src="sb1.jpg" class="slide-4">





   <ul>


<li>savings account</li>
<li>credit cards</li>
<li>fixed deposit</li>
<li>personal loan</li>
 <li>home loan</li>
<li>business loan</li>
<li>debit card</li>
<li>loan against property</li>
 <li>car loan</li>
 <li>gold loan</li>


      </div>
      </div>


    </section>


<!---liniig---->


<section class="chat">
  <div class="content-box">
    <div class="container">

<h1>Chat</h1>

<div class="h">

<div class= "banner-text">

        <a href="chatmain.php">CHAT ROOM  </a>
</div>

</div>
</div>
</div>
</section>
<!---liniig---->









<!--////////////////////////////////////--->

<section class="chat">
  <div class="content-box">
    <div class="container">

<h1>ONLINE SERVICE</h1>

<div class="h">

<div class= "banner-text">

        <a href="https://docs.google.com/forms/d/1o7Hv1iL3c9c9LflwSCCWCKvPfg888dOYc6Chf3SFKCc/viewform?edit_requested=true">PERSONAL INFORMATION</a>





</div>


<div class= "banner-text">

        <a href="in.php">PHOTO UPLOAD</a>




</div>




</div>
</div>
</div>
</section>



<!---liniig---->










<!---liniig---->

<section class="footer">

  <div class="content-box">
    <div class="container">

   <h1>GET IN TOUCH</h1>

  <div  class="row">

<?php

include('new.php')

?>

<script  type="application/php" src="new.php"></script>


   <div class="col-md-6  contact-info">
     <div class="follow">
       <i class="fa fa-map-marker"></i><span>QTR NO 23 NEAR MSME TOOL ROOM  PIN CODE.495009 KOLKATA</span>
   </div>

   <div class="follow">
     <i class="fa fa-phone"></i><span>8349201124</span>
 </div>

  <div class="follow">
   <i class="fa fa-envelope-o"></i><span>mtechcorp@gmail.com</span>
</div>


<div class="follow">
  <i class="fa fa-facebook"></i>
  <i class="fa fa-twitter"></i>
    <i class="fa fa-instagram"></i>


</div>


  </div>

    </div>
 <hr>
 <p   class="hi">  <i class="fa fa-laptop"></i>  &nbsp; Website Made By  &nbsp; &nbsp; <i class="fa fa-user-circle-o">  &nbsp; </i> <b> Harsh Nayak   &nbsp;  &nbsp; <i class="fa fa-user-circle-o">  &nbsp; </i>  Garima Singh  &nbsp;  &nbsp;   <i class="fa fa-user-circle-o">  &nbsp; </i> Mukesh Verma   &nbsp;  &nbsp;  <i class="fa fa-user-circle-o">  &nbsp; </i>  Ramesh Kumar Markam<b></p>
  </div>
</div>
</section>



<!---liniig---->




</body>
</html>
