
<?php

if(isset($_REQUEST['submit'])){

if(($_REQUEST['name']== "") && ($_REQUEST['number']== "") && ($_REQUEST['email']== "") && ($_REQUEST['message']== ""))

     {

   $msg='<div class ="alert alert-warning col-sm-6 ml-5 mt-2" role="alert">FILL ALL FEILD</div>';
 }else{

   $name = $_REQUEST['name'];
   $subject = $_REQUEST['number'];
   $email = $_REQUEST['email'];
   $message = $_REQUEST['message'];

   $mailTo = "harsh.nayak.12131@gmail.com";
   $headers = "From: ".$email;
   $txt="you have received an email from ".$name. ".\n\n".$message;
   mail($mailTo, $subject, $txt, $headers);

   $msg='<div class ="alert alert-success col-sm-6 ml-1 mt-2" role="alert">sen successfullyt</div>';
 }

}

 ?>

<div class="col-md-6">

<form class="contact-form"  method="post" >

 <div class="form-group" >
 <input type="text"  class="form-control"  name="name" placeholder="yourname">
</div>

<div class="form-group">
<input type="number"  class="form-control" name="number"  placeholder="phone number">
</div>

<div class="form-group">
<input type="email"  class="form-control"  name="email" placeholder="Email id">
</div>

<div class="form-group">
<textarea class="form-control" rows="4" name="message"  placeholder="your message">
</textarea>
</div>

<button type="submit" name="submit" class="btn btn-primary">Send Message</button>

<?php
 if(isset($msg)) {

   echo $msg;
 }
 ?>
</form>


</div>
